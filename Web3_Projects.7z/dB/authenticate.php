<?
    // Check for user authentication
    // If not authenticated, send user back to login page
    if (!$_SESSION[authenticated]){
        // redirect user
        header("Location: http://localhost/dB/login.php?url=" . urlencode($_SERVER["SCRIPT_NAME"]));
    }
?>