# phpMyAdmin MySQL-Dump
# version 2.3.3pl1
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Apr 20, 2007 at 12:02 PM
# Server version: 3.23.49
# PHP Version: 4.1.2
# Database : `coolquotes`
# --------------------------------------------------------

#
# Table structure for table `authors`
#

CREATE TABLE authors (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `authors`
#

INSERT INTO authors VALUES (67, 'Chevy Chase');
INSERT INTO authors VALUES (68, 'Winston Churchill');
INSERT INTO authors VALUES (5, 'Abraham Lincoln');
INSERT INTO authors VALUES (6, 'Benjamin Franklin');
INSERT INTO authors VALUES (39, 'Arnold');
INSERT INTO authors VALUES (12, 'Jon  C. Cooley');
INSERT INTO authors VALUES (9, 'Billy "the Kid" Hintz');
INSERT INTO authors VALUES (55, 'Dan Sarauer');
INSERT INTO authors VALUES (40, 'Sir Hacksalot');
INSERT INTO authors VALUES (50, 'Some Guy');
INSERT INTO authors VALUES (42, 'Regis Philbin');
INSERT INTO authors VALUES (53, 'Marie Antoinette');
INSERT INTO authors VALUES (51, 'Frank Castle - The Punisher');
INSERT INTO authors VALUES (62, 'News Headline');
INSERT INTO authors VALUES (64, 'Bankei');
