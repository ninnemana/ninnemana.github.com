<?php
session_start();
require 'authenticate.php';
?>
<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Quote Site Content Management System (CMS)</h2>
        <ul>
            <li><a href="quotes/quotesAdmin.php">Manage Quotes</a></li>
            <li><a href="authors/authorsAdmin.php">Manage Authors</a></li>
        </ul>

        <a href="login.php?logout=1">Log Out</a>
        <?php
        print "<h3>SCRIPT_NAME from the SERVER array contains $_SERVER[SCRIPT_NAME]</h3>";
        ?>
    </body>
</html>
