<?php
session_start();
require '../authenticate.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>CMS - Author Modification</title>

        <style>

        body {
            text-align:center;
            margin:auto;
        }
        h2 {
            color: navy;
            font-family: Helvetica, Verdana;
        }

        table {
            margin: auto;
            width: 50%;
            border-style:outset;
            border-width:4px;
        }

        td {
            padding: 4px;
            border-style:outset;
            border-width:2px;
        }

        td.author {
            color:#CCCC99;
            background-color:#336699;
            font-family:cursive;
            vertical-align: top;
            text-align:center;
        }

        td.authorid{
            color: peachpuff;
            background-color:#336699;
            font-family:cursive, Verdana;
            vertical-align: top;
            font-weight:600
        }

        td.linkStuff {
            font-family: Arial Narrow, Verdana;
            font-size: 0.8em;
            font-weight: 600;
            text-align: center;
        }

        td.author:first-letter {
            font-size:1.3em;
            font-weight: 600;
        }

        </style>
    </head>
    <body>
        <h2>Manage Authors</h2>
        <?php
        // connect to dB server and select dB
        require '../dbConnect.php';

        // Query our dB and get our authors content
        $result = @mysql_query("SELECT * FROM authors ORDER BY name");
        if (!$result) {
            exit("<p style=\"color:red\">Error retrieving authors.</p>");
        }

        // start table output
        print "<table>\n\n";

        // Step through each row of the result set(author name & ID)
        while($row = mysql_fetch_array($result)) {
            print "<tr>\n";
                print "<td class=\"author\">$row[name]</td>";
                print "<td class=\"authorID\">$row[id]</td>";

                print <<<LINKS
                <td class="linkStuff">
                <a href="editAuthor.php?authorid=$row[id]&authorname=$row[name]">Edit</a><br />
                <a href="deleteAuthor.php?authorid=$row[id]&authorname=$row[name]">Delete</a><br />
LINKS;
            print "</tr>\n";
        } // end while not at end of result set
        print "</table>\n";
        ?>
    </body>
</html>
