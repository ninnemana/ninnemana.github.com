<?php

// obtain password from the mypasswd file
$fp = fopen("mypasswd.txt", "r");
$mypass = trim(fgets($fp, 1024));

// Connect to our dB server
$dbcnx = @mysql_connect("localhost", root, '');

// check if our connection worked
if(!$dbcnx) {
	exit("<p style=\"color:red\">Unable to connect to the database server at this time </p>");
}

if(!@mysql_select_db("authors")) {
	exit("<p style=\"color:red\">Unable to connect to the database server at this time </p>");
}

?>