<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
print <<<TOP
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Quote Listing</title>

<style>

    h2 {
        color: navy;
        font-family: Trebuchet MS;
        }

    #author {
        font-weight: 600;
        font-size: 0.7em;
        color: darkgreen;
        font-family: Comic Sans MS;
        }

</style>

</head>

<body>
TOP;

// check if our add new quote link has been clicked
if ($_GET[clicked] == 1) {

    // Reset the control variable (clicked)
    unset($_GET[clicked]);	// or set $_GET[clicked] = 0

    // display add new quote form
    print <<< MYFORM

    <form action="$_SERVER[PHP_SELF]" method="POST">
    <label id="quoteArea">Enter the quote text:</label><br />
    <textarea name="newQuote" id="newQuote" rows="10" cols="40">Enter quote...</textarea><br /><br />
    <label id="quoteAuthor">Enter the author of this quote:</label><br />
    <input type="text" name="newAuthor" id="newAuthor" />
    <br /><br />
    <input type="submit" name="submit" value="Quote It" />
    </form>

MYFORM;

}
else {  // add new quote link not clicked, so display quote

    print "<h2>My Favorite Quotes</h2>\n\n";
    print "<h3>Here are all the quotes in our database</h3>\n\n";

    // Connect to our dB server using an include file
    #include 'dbConnect.php';
    require "dbConnect.php";

    // Run our query on the database.

    // Check which kind of query we should be running.
    // We need to insert a new quote if one was submitted.

    // Check if form to add new quote was submitted.
    if(isset($_POST[submit]) && ($newQuote = trim(strip_tags($_POST[newQuote])))) {

        // check if an author was entered for this quote.
        // and remove any html tags that they might be trying to hijack with.
        $newAuthor = trim(strip_tags($_POST[newAuthor]));
        if ($newAuthor == "") {
            $newAuthor = "Unknown";
        }

        // do a couple of debugging prints.
        print "<h3>New Quote = $newQuote<br />";
        print "New Author = $newAuthor</h3>";

        // check if new quote already exists in our database.
        $result = @mysql_query("SELECT  quotetxt
                                FROM quotes
                                WHERE quotetxt = '$newQuote'");

        // Check if our query failed and exit if it did
        if (!$result) {
            exit("<p style=\"color:red\">Query for new quote failed</p>\n");
        }

        // Did we find the new quote?
        if (@mysql_num_rows($result) > 0) {
            // the quote was found -- duplicate
            print ("<h3>The quote was found -- duplicate.</h3>\n");
        }
        else { // quote was not found
            print("<h3>The quote was not found.... Adding new quote.</h3>\n");

            // check if author for new quote exists in our authors table
            $authorResult = @mysql_query("SELECT id
                                          FROM authors
                                          WHERE name = '$newAuthor'");
            // Check if our query failed and exit if it did.
            if (!$authorResult) {
                exit("<p style=\"color:red\">Query for new author failed</p>\n");
            }

            // Did we find out author
            if (@mysql_num_rows($authorResult) > 0) {
                // the author was found -- duplicate
                print ("<h3>The author was found -- duplicate.</h3>\n");
            }
            else { // the author was not found
                print ("<h3>The author was NOT found</h3>\n");

                // Add new author to our authors table and obtain its ID.
                $sql = "INSERT INTO authors SET name='$newAuthor'";

                // Do the query and see if it worked
                if (@mysql_query($sql)) {
                    print ("<h3>Your new author $newAuthor has been added.</h3>\n");

                    // Now get the ID for the new author.
                    if (!($authorResult = @mysql_query("SELECT id FROM authors WHERE name = '$newAuthor'"))) {
                        exit("<p style=\"color:red\">Query for author failed</p>\n");
                    }
                }
                else {
                 exit("<p style=\"color:red\">Error inserting new author</p>\n");
                }

                } // end else - author was not found.
            }


            // obtain author ID for the author submitted via the form
            $row = @mysql_fetch_array($authorResult);
            // $row is now an associative array containing a single element whose subscript(key) is 'id'.

            // Insert our new quote into the quotes table.
            $sql = "INSERT INTO quotes(quotetxt, authorid) VALUES('$newQuote', '$row[id]')";
            if (@mysql_query($sql)) {
                print "<h3>Your quote $newQuote has been added.</h3>";
            }
            else {
                print "<h3 style=\"color:red\">Connection failed while adding quote. Quote not added.</h3>\n\n";
            }
               
        } // end else - quote was not found.

    } // end if - new quote submitted

    // Obtain and display all quotes and their authors from database.
    $resultID = @mysql_query("SELECT quotetxt, name
                              FROM quotes, authors
                              WHERE authors.id=quotes.authorID");
    if (!$resultID) { // Our query failed - servere problem
        exit("<p style=\"color:red\">Error retrieving data from database</p>\n");
    }

    // Display our results
    print "<blockquote>\n";

       // Step throug the query result set one row at a time.
       while($row = mysql_fetch_array($resultID)) {
           print "<p>$row[quotetxt]<br />\n";
           print "<span id=\"author\">$row[name]</span></p>\n\n";
       } // end while not at end of result set.

    print "<blockquote>\n\n";

    // display our add a new quote link
    print "<a href=\"$_SERVER[PHP_SELF]?clicked=1\">Add a quote</a>\n\n";



print <<<BOTTOM
</body>
</html>
BOTTOM;
?>
