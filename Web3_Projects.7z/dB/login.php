<?php

session_start();

if (isset($_POST[clickit])) {    // login form has been submitted

   // acquire username and password from form
   $uname = trim($_POST[username]);
   $pword = trim($_POST[password]);

   if ($uname == "" || $pword == "") {
      print "<h3 style=\"color:red\">You must enter both a username and password</h3>\n";
   }
   else {    // proceed with account check

      require 'dbConnect.php';

      $pword = md5($pword);   // encrypt password that came from form

      // let's query our users table to see if we have an account match
      $result = @mysql_query("SELECT * FROM users
                              WHERE username='$uname'
			      AND pword='$pword'");

      if (!$result) {
         exit("<p style=\"color:red\">Error retrieving account info</p>");
      }

      // check if we have a match
      if (mysql_num_rows($result) > 0) {

         $_SESSION[authenticated] = true;   // grant them admin access

         // redirect authenticated user to where they came from OR
	 // to the admin page
         if ($_SESSION[targetUrl]) {  // user came from one of our private pages
            $url = $_SESSION[targetUrl];
	 }
	 else {   // user did not come from one of our private pages
            $url = "admin.php";
	 }

         // do the actual redirection
	 header("Location: $url");

      }   // end if we had a match
      else {   // could NOT find a match
         print "<h3 style=\"color:red\">Invalid credentials - Please try again</h3>\n\n";
      }

   }
}   // end if login form was submitted
else {  // check to see if user is logging out
   if ($_GET[logout] == 1) {
      unset($_SESSION[authenticated]);
      // if register_globals is turned On, must also do this
      unset($authenticated);
   }
   $_SESSION[targetUrl] = $_GET[url]; // remember passed in url
}
print <<<TOP

<?xml version="1.0"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>CMS Login page</title>

<style>

</style>

</head>

<body>

<h2 id="myh2">Please login to gain administrative access</h2>

<form action="$_SERVER[PHP_SELF]" method="POST">

   <label>Username:</label>
   <input type="text" id="username" name="username" /><br /><br />

   <label>Password:</label>
   <input type="password" name="password" /><br /><br />

   <input type="submit" name="clickit" value="Log In" />

</form>

TOP;



print <<<BOTTOM

</body>
</html>
BOTTOM;

?>