# phpMyAdmin MySQL-Dump
# version 2.3.3pl1
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Apr 20, 2007 at 12:02 PM
# Server version: 3.23.49
# PHP Version: 4.1.2
# Database : `coolquotes`
# --------------------------------------------------------

#
# Table structure for table `quotes`
#

CREATE TABLE quotes (
  id int(11) NOT NULL auto_increment,
  quotetxt text NOT NULL,
  authorid int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table `quotes`
#

INSERT INTO quotes VALUES (91, 'Do not speak- unless it improves on silence.', 55);
INSERT INTO quotes VALUES (90, 'In criticizing, the teacher is hoping to teach. That\'s all.', 64);
INSERT INTO quotes VALUES (88, 'War dims hope for peace...', 62);
INSERT INTO quotes VALUES (77, 'Your\'e fired!   ', 39);
INSERT INTO quotes VALUES (78, 'Blah Blah Blah Blah  ', 55);
INSERT INTO quotes VALUES (92, 'There is one thing I know...and that is this.', 55);
INSERT INTO quotes VALUES (82, 'Don\'t Worry, be happy   ', 58);
INSERT INTO quotes VALUES (25, 'He can compress the most words into the smallest ideas of any man I ever met.      ', 5);
INSERT INTO quotes VALUES (13, 'Better to remain silent and be thought a fool than to speak out and remove all doubt.   ', 5);
INSERT INTO quotes VALUES (14, 'Force is all-conquering, but its victories are short-lived.   ', 5);
INSERT INTO quotes VALUES (15, 'Be civil to all; sociable to many; familiar with few; friend to one; enemy to none.   ', 6);
INSERT INTO quotes VALUES (75, 'Let them eat cake   ', 53);
INSERT INTO quotes VALUES (64, 'Is that your final answer?   ', 42);
INSERT INTO quotes VALUES (74, 'Hasta La Vista   ', 39);
INSERT INTO quotes VALUES (61, 'To be or not to be..., not to be   ', 39);
INSERT INTO quotes VALUES (62, 'I\'ll be back   ', 39);
INSERT INTO quotes VALUES (72, 'Sicvis pacum parabelum.', 51);
INSERT INTO quotes VALUES (71, 'Wherever you go, there you are   ', 50);
INSERT INTO quotes VALUES (28, 'A mind is like a parachute; it works best when opened.     ', 12);
INSERT INTO quotes VALUES (102, 'A flute with no holes is not a flute and a donut with no holes is a danish', 67);
INSERT INTO quotes VALUES (103, 'I may be drunk, Miss, but in the morning I\'ll be sober and you will still be ugly.', 68);
