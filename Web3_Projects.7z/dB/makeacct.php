<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Create quotes dB CMS Admin Account</title>
    </head>
    <body>
        <?php
        //
        // Connect to our dB Server and select our database
        //
        require 'dbConnect.php';

        //
        // Drop and exisitng users table.
        //
        if (!@mysql_query("DROP TABLE users")){
            print "<p style=\"color:red\">Could not drop table.</p>\n";
        }

        //
        // (Re)create users table
        //
        if (!@mysql_query("CREATE TABLE users
                           (
                            username varchar(255) primary key,
                            pword varchar(255)
                            )"
                            )) {
                                 exit("<p style=\"color:red\">Unable to create table.</p>\n");
                            }
           


        //
        // Open and read data from our ID's input file.
        //
        $fp = fopen("ids_sp2009", "r");

        while (!feof($fp)){
            // read next line of data from file
            $username = trim(fgets($fp, 255));  // trim off whitespace and trailing \n

            // if fgets() gave us a valid line of data
            if($username != ""){
                print "<h3>Username is: $username ------";
                // contruct password
                $password = md5(ucfirst(substr($username, 0, 4)) . "123");

                print "password is: $password</h3>\n";

                // insert username and password into our users table
                $sql = "INSERT INTO users
                        VALUES ('$username', '$password')";

                if (@mysql_query($sql)){
                    print "<h3>Your account has been added.</h3>";
                }
                else {
                    exit("<p style=\"color:red\">Error adding acount.</p>\n");
                }
            } // end if - we have valid line
        } // end while - not end of file
        fclose($fp);
        ?>
    </body>
</html>
