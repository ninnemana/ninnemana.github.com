<?php

print <<<TOP

<?xml version="1.0"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Pig Latin Translator</title>

</head>

<body>
TOP;
$myForm = <<<MYFORM
<div class="myForm">
<h2>Pig Latin Translator</h2>
<form name="pigLatin" action="$_SERVER[PHP_SELF]" method="post">
<input type="text" name="original" size="40" />
<br /><br />
<input type="submit" name="pigify" value="Generate Translation" />
<!--<input type="button" name="clear" value="Clear" />-->
</form>
</div>
MYFORM;



if (!isset($_POST[pigify])) { 	// display the form
	print $myForm;
} // end if
else {

	$original = $_POST[original];
    $words = explode(" ", $original);
    
    foreach ($words as $word) {
        $word = rtrim($word);
        $firstChar = substr($word, 0, 1);
        $rest = substr($word, 1, strlen($word));
		
        if(strstr('aeiou', $firstChar)) {
        	$word = $word . "way ";
            print $word;
        }
        else {
        	$word = $rest . $firstChar . "ay ";
            print $word;
         }
    } // end foreach
    
    
} // end if

print <<<BOTTOM
</body>
</html>
BOTTOM;
?>