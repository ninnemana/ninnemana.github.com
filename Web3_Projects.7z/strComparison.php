<?php
print <<<TOP
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

TOP;
if (isset($_POST[go])) {

	$userName = strip_tags($_POST[uname]);
	
	$unameLength = strlen($userName);
	
	if ($unameLength > 5 && $unameLength < 9) {
		print "<h3 style=\"color:red\">$userName is a valid username.</h3>\n";
	}
	else {
		print "<h3 style=\"color:red\">$userName ($unameLength characters is not valid. <br />It must be between 6-8 characters in length</h3>\n";
	}
}
else {
	print <<<MYFORM
    <form action="$_SERVER[PHP_SELF]" method="post">
    	<label>Username: </label><input type="text" name="uname" />
        <br /><br />
        <input type="submit" name="go" value="Go" />
    </form>
	
MYFORM;
}

// string comparison
//$str1 = "Wash";
//$str2 = "Washington";
$str1 = "Obama";
$str2 = "Lincoln";

$result = strcmp($str1, $str2);

if ($result < 0) {
	print "<h4>$str1 is less than $str2 - \$result = $result</h4>\n";
}
elseif ($result > 0) {
	print "<h4>$str1 is greater than $str2 - \$result = $result</h4>\n";
}
else {
	print "<h4>$str1 is equal than $str2 - \$result = $result</h4>\n";
}

// Do some substring examples
$greeting = "good morning citizen";
print "<h4>$greeting</h4>";
$farewell = substr_replace($greeting, "bye", 5, 7);
print "<h4>\$farewell now contains: $farewell</h4>";
$farewell = substr_replace($farewell, "kind ", 9, 0);
print "<h4>\$farewell now contains: $farewell</h4>";

// Delete everything following "good bye"
$farewell = substr_replace($farewell, "", 8);
print "<h4>\$farewell now contains: $farewell</h4>";

// Insert "now it's time to say " at the beginning
$farewell = substr_replace($farewell, "now it's time to say ", 0, 0);
print "<h4>\$farewell now contains: $farewell</h4>";

// Replace "bye" with "riddance" starting from the end of the string
$farewell = substr_replace($farewell, "riddance", -3);
print "<h4>\$farewell now contains: $farewell</h4>";

// Delete "rid" from the string, starting from the end
$farewell = substr_replace($farewell, "", -8, 3);
print "<h4>\$farewell now contains: $farewell</h4>";

print <<<BOTTOM

</body>
</html>
BOTTOM;
?>