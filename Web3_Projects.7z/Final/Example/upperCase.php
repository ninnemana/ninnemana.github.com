<?php
      if (isset($_GET['inputText'])){
        echo strtoupper($_GET['inputText']);
      }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>AJAX - PHP Example</title>

        <script language="javascript" type="text/javascript">
            // Get the HTTP Object
            function getHTTPObject(){
                if (window.ActiveXObject)
                    return new ActiveXObject("Microsoft.XMLHTTP");
                else if (window.XMLHttpRequest)
                    return new XMLHttpRequest();
                else {
                    alert("Your browser does not support AJAX.");
                    return null;
                }
            }

            function doWork(){
                httpObject = getHTTPObject();
                if (httpObject != null) {
                    httpObject.open("GET", "upperCase.php?inputText="
                        +document.getElementById('inputText').value, true);
                    httpObject.send(null);
                    httpObject.onreadystatechange = setOutput;
                }
            }

            // Change the value of the outputText field
            function setOutput(){
                if(httpObject.readyState == 4){
                    document.getElementById('outputText').value
                        = httpObject.responseText;
                }
            }
            var httpObject = null;
        </script>
    </head>
    <body>
        <form name="testForm">
            Input text: <input type="text" onkeyup="doWork();" name="inputText" id="inputText" />
            Output text: <input type="text" name="outputText" id="outputText" />
        </form>
        
    </body>
</html>
