<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        print <<<TOP

<?xml version="1.0"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Total Cost Assignment</title>

<style>

	body {
		color: $_POST[fg];
		background-color: $_POST[bg];
		font-family: $_POST[fontchoice];
	}

</style>

</head>

<body>

<h3> Welcome $_POST[fname] $_POST[lname]</h3>
TOP;

// Initialize variables
$costPerWidget = 20;
$taxRate = .06;
$discountRate = .25;
$totalCost = 0;
$discountCeiling = 50;

$qty = $_POST[Quantity];
if ($qty > 0){   // run calculations
	// determine pre-tax total cost
	$totalCost = $costPerWidget * $qty;

	// determine if discount should be applied, only if total cost is $50 or greater
	if($totalCost >= $discountCeiling) {
		// apply discount (discount = totalCost * discountRate)
		$discount = $totalCost * $discountRate;
		$totalCost = $totalCost - ($totalCost * $discountRate);
	}

	// apply tax and update total cost
	$taxAmount = $totalCost * $taxRate;
	$totalCost += $taxAmount;   // same as totalCost = totalCost + taxAmount

	// determine monthly installments
	$monthlyPayment = round($totalCost/12, 2);

	// output our results
	print "<p>You requested $qty widget(s) at $$costPerWidget each</p>\n\n";

	// check
	if($discount){
		printf("<p>Your total with tax, minus your \$%.2f discount, comes to \$%.2f</p>", $discount, $totalCost);
	}
	else { // no discount
		printf("<p>Your total with tax comes to \$%.2f</p>", $totalCost);
	}

	// display monthly payment
	printf("<p>You may purchase the widget(s) in 12 monthly installments of \$%.2f each.<p>", $monthlyPayment);
}

else {     /// user needs to enter a valid number of widgets
	// display error message
	print <<<ERRMSG
<h3 style="background-color: $_POST[fg]; color: $_POST[bg]; border-style: outset; border-width: 4px; width: 80%;">
Please make sure that you have entered a quantity and then resubmit.
</h3>
ERRMSG;
}
print <<<BOTTOM

</body>
</html>
BOTTOM;
        ?>
    </body>
</html>
