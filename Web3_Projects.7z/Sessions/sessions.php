<?php
session_start();

// User could be coming to this page via one of three scenarios:
// 1. directly from sessions.html
// 2. from another page in this site (they filled out the form previously)
// 3. directly to this page without filling out the form at all

if (isset($_POST[submit])) { // user came directly from form
	$bg = $_SESSION[background] = $_POST[backColor];
	$fg = $_SESSION[background] = $_POST[foreColor];
}
elseif ($_SESSION[background] != "") {
	$bg = $_SESSION[background];
	$fg = $_SESSION[background];
}
else { // user did not use the form
	// if these two assignments are left in place, the second time we come to this page without submitting form
	// we will be redirected to sessions.html
	
	//$bg = $_SESSION[background] = "magenta";
	//$fg = $_SESSION[background] = "limegreen";
	// redirect user to form page
	header ("Loaction: sessions.html");
}
print <<<TOP

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sessions Example</title>

<style>

	body {
		background-color: $bg;
		color: $fg;
	}
	
</style>

</head>

<body>

<h2>Testing of session variables for Web3</h2>

TOP;




print <<<BOTTOM

<a href="sessions_page2.php">Click here to go to another page in this site.</a>
</body>
</html>
BOTTOM;
?>