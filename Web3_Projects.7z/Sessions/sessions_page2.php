<?php
session_start();

print <<<TOP
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sessions Example Page 2</title>

<style>

	body {
		background-color: $_SESSION[background];
		color: $_SESSION[foreground];
	}
</style>

</head>

<body>
<h2>This is page2 in our Sessions Example</h2>
<a href="sessions.php">sessions.php</a>
<br /><br />
TOP;

print "Session cookie name: " . session_name() . "<br />";
print "Session ID: " . session_id() . "<br />";
print "Session filepath: " . session_save_path() . "<br />";

$_SESSION[ctr]++;
print "this is visit: #$_SESSION[ctr] for you to this page. <br />";
print "The value of ctr is: " . $_SESSION[ctr] . " on this page.";

print <<<BOTTOM
</body>
</html>
BOTTOM;
?>