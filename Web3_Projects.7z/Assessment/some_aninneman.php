<?php

print <<<PARTONE

<?xml version="1.0"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Loginid Generation - Web III Assessment #1</title>

</head>

<body>
PARTONE;
    $lastname = $_POST[lastname];
    $firstname = $_POST[firstname];
    $middle = $_POST[mi];


    $first_initial = substr($firstname, 0, 1);

    if(strlen($lastname) < 6) {
        $loginid = strtolower($lastname . $first_initial . $middle);
    }
    else {
        $loginid = substr($lastname, 0, 6);
        $loginid = strtolower($loginid . $first_initial . $middle);
    }
    $count = strlen($loginid);
    print "<h2>You're new <span style=\"color:#00FF00\">$count</span>-character username is <span style=\"color:#0000FF; font-family:Verdana\">$loginid</span></h2>";

print <<<PARTTWO
</body>
</html>
PARTTWO;
?>

