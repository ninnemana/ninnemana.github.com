<?php

print <<<TOP
<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Handling HTML special characters in PHP</title>

<style>

    th {
       font-family: Algerian;
       color: navy;
       font-weight: 500;
       font-size: 1.4em;
    }

    td {
       font-family: Trebuchet MS;
       font-size: 1.2em;
    }

    td.char {
       color: rgb(40, 100, 200);
    }

    td.entity {
       color: rgb(200, 100, 40);
       font-family: Verdana;
    }

</style>

</head>

<body>

<table border="1" cellpadding="4px">

<tr>
   <th>Character</th>
   <th>Entity</th>
</tr>

TOP;

// step though the associative array returned by 
// get_html_translation_table() one element at a time
foreach (get_html_translation_table(HTML_ENTITIES) as $key => $value) {

   if ($key == $value) {
      $result = 1;
   }
   else {  // $key != $value
      $result = 0;
   }

   $spchar = htmlentities($key);
   $entity = htmlspecialchars($value);

   print "<tr>\n";
   print "<td class=\"char\">$key **$result** $value</td>\n";
   print "<td class=\"entity\">\$spchar = $spchar *** \$entity = $entity</td>\n";
   print "</tr>\n\n";

}  // end foreach

print "</table>\n\n";


print <<<BOTTOM

</body>
</html>
BOTTOM;

?>
