
<?php
print <<<TOP



<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>PHP template 2</title>


</head>

<body>
TOP;

if (isset($_POST[go])) {

	$userName = $_POST[uname];
	
	$unameLength = strlen($userName);
	
	if ($unameLength > 5 && $unameLength < 9) {
		print "<h3 style=\"color:red\">$userName is a valid username.</h3>\n";
	}
	else {
		print "<h3 style=\"color:red\">$userName ($unameLength characters is not valid. <br />It must be between 6-8 characters in length</h3>\n";
	}
}
else {
	print <<<MYFORM
    <form action="$_SERVER[PHP_SELF]" method="post">
    	<label>Username: </label><input type="text" name="uname" />
        <br /><br />
        <input type="submit" name="go" value="Go" />
    </form>
}

print <<<BOTTOM

</body>
</html>
BOTTOM;
?>