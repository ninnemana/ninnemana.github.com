<?php
setCookie("firstname", "Alex");
setCookie("username", "ninnemana", time() + 60 * 3);
setCookie("cookieMonster", "coookiessss", mktime(15,49,0,2,18,2009));

print <<<TOP
<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Cookies In PHP</title>
</head>

<body>
<h2>Cookies in PHP</h2>
TOP;

print "<h3>\$_COOKIE[firstname] contains $_COOKIE[firstname]</h3>\n";
print "<h4>\$_COOKIE[username] will expire in: $_COOKIE[username]</h4>\n";
print "<h4>\$_COOKIE[cookieMonster] contains $_COOKIE[cookieMonster]</h4>\n";

print <<<BOTTOM

</body>
</html>
BOTTOM;

?>
