<?php

print <<<TOP

<?xml version="1.0"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>PHP template</title>

<style>

</style>

</head>

<body>

TOP;

print "<h1 style=\"color:green\">This is my first PHP web page</h1>\n";
print "<p>PHP is used to generate web pages on the fly.  When this page is left by the user, it will vaporize</p>\n";

/*
for ($ctr = 1; $ctr <= 6; $ctr++) {
?>
<h3>PHP is interesting</h3>
<?php
}  // end for loop
*/

// define a named constant
define("DEM", "blue");
define("GOP", "red");

print "<span style=\"color:" . DEM . "\">Wisconsin</span> is a " . DEM ." state\n";

for ($ctr = 1; $ctr <= 6; $ctr++) {
   echo "<h$ctr>This is a header $ctr</h$ctr>\n";
}  // end for loop

#phpinfo();

if (isset($_GET[Go])) {  // form has been submitted - process form data

   // if form has been submitted then the rest of the form's
   // data is also available through the $_GET associative array.
   // We can get to each form field's data by using that form
   // field's name as a subscript of the $_GET array.

   // ensure user entered their first name in the fname form
   // field and greet them
   if ($_GET[fname] != "") {   // fname has something in it
      print "<h3>Welcome $_GET[fname]!</h3>\n";
   }
   else {   // fname field is empty
      print "<h3 style=\"color:red\">Who are you?</h3>\n";
   }

   $num1 = $_GET[first];  // use $num1 as a shortcut
   $num2 = $_GET[second]; // use $num2 as a shortcut
   $sum = $num1 + $num2;
   $diff = $num1 - $num2;
   $product = $num1 * $num2;
   $quotient = $num1 / $num2;
   $remainder = $num1 % $num2;

   print <<<PHPOPS

<table border="3px" cellpadding="4px">

<tr>
   <td>$num1 + $num2</td>
   <td>sum = $sum</td>
</tr>
<tr>
   <td>$num1 - $num2</td>
   <td>difference = $diff</td>
</tr>
<tr>
   <td>$num1 * $num2</td>
   <td>product = $product</td>
</tr>
<tr>
   <td>$num1 / $num2</td>
   <td>quotient = $quotient</td>
</tr>
<tr>
   <td>$num1 % $num2</td>
   <td>remainder = $remainder</td>
</tr>

</table>

PHPOPS;

$loginid = $_GET[fname] . $_GET[first];


	//example of an if-elseif-else
	if($_GET[first] < $_GET[second]){
		$loginid = $_GET[fname] . $_GET[first];
	}
	elseif ($_GET[second] < $_GET[first]){
		$loginid = $_GET[fname] . $_GET[second];
	}
	else{
		$loginid = $_GET[fname] . 20;
	}
	print "Your new loginid is $loginid\n";
	
	// example of a while loop
	$ctr = $_GET[second];
	while($ctr >= $_GET[first]) {
			print "$ctr ... ";
			$ctr--;    // or $ctr = $ctr - 1; or --$ctr; or $ctr -= 1;
	}
	print "Blast OFF!";

    // Display a multiplication table using numbers from form
    print "<table border = \"3px\" cellpadding = \"4px\">\n\n";

    // outer for loop to produce table rows
    for ($rows = 1; $rows <= ($_GET[first]); $rows++){
        print "  <tr>\n";

        // inner for loop to produce columns for this row
        for ($cols = 1; $cols <= ($_GET[second]); $cols++) {
            print "<td>" . $rows * $cols . "</td>\n";
        }

        print "  </tr>\n";
    }
}
else {   // form has NOT been submitted - show it

   print <<<MYFORM
<form action="$PHP_SELF" method="GET">

<label>First Name:</label><br />
<input type="text" name="fname" id="fname" />
<br /><br />

<label>First Number:</label><br />
<input type="text" name="first" id="first" />
<br /><br />

<label>Second Number:</label><br />
<input type="text" name="second" id="second" />
<br /><br />

<input type="submit" name="Go" value="Go for it" />

MYFORM;

}

print <<<BOTTOM

</body>
</html>
BOTTOM;

?>
