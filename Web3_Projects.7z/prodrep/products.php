<?php

print <<<TOP
<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www/w3/org/TR/xhtml/11/DTD/xhtml1-
transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Product Report</title>

<style>

	body {
		background-color:#CCCC99;
		color:#660000;
		font-family:Algerian, Verdana;
	}
	
	.myform {
		text-align:center;
	}
	
	h2 {
		color: navy;
		text-align:center;
	}
	
	table {
		border-width:thin;
		border-style:ridge;
		width: 820px;
		margin:auto;
	}
	
	td {
		background-color: black;
		font-size:0.8em;
		padding: 5px;
	}
	
	td.diff {
		background-color: beige;
		color:#660000;
		font-family:Trebuchet MS, Verdana;
	}
	
	td.img {
		text-align:center;
		background-color: black;
		font-size:0.8em;
		padding: 5px;
	}

</style>

</head>

<body>

TOP;

$myform = <<<MYFORM

<div class="myform">

<h2>Minisworld Company Product Report</h2>

<form name="report" action="$_SERVER[PHP_SELF]" method="post">

<label>First Name</label>
<input type="text" name="fname" size="20" />
<br /><br />

<label>Last Name</label>
<input type="text" name="lname" size="20" />
<br /><br />

<label>Product Report Choices</label><br />
<select name="choices[]" multiple="MULTIPLE">

	<option value="figs" selected>Painted Figures</option>
    <option value="scenery">Town Square Scenery</option>
    <option value="supplies">Misc Scenic Supplies</option>
</select>
<br /><br />

<input type="submit" name="go" value="Generate Product Report" />
</form>
</div>
MYFORM;

// check to see if we should display the form or we should process the submitted form and display the product report.
if (!isset($_POST[go])) { 	// display the form
	print $myform;
} // end if
else {		// form has been submitted - process form data
	// display greeting
    print "<h2>Welcome <span style=\"color:#660000\">$_POST[fname] $_POST[lname]</span></h2>\n\n";
    
    if (count($_POST[choices]) == 0) {
    
    	print "<h2>No product categories were chosen</h2>\n";
    } // end if
    else {		// we now know at least one category was selected
    
    	// associate report name with our filename
        $reportName["figs"] = "Painted Figures";
        $reportName["scenery"] = "Town Square Scenery";
        $reportName["supplies"] = "Misc Scenic Supplies";   
    
    	// produce a table of product info for each selected category
        foreach ($_POST[choices] as $filename) {
        	//print"<h4>\$filename contains $filename</h4>";
            

            
            // display header for the product category
            print "<h2>$reportName[$filename] Product Report for " . date("Y") . "</h2>\n\n";
            
            // obtain product info for all products in this category and display them one per row in a table
            print "<table>\n\n";
            
            $fp = fopen($filename, "r");
            
            while (!feof($fp)) {	// not EOF, read next line
            	
                // read and return next line as a string
                $line = fgets($fp, 1024);
                
                // fix for FEOF going one line past EOF
                if($line !="") {	// we have a valid line of data
                
                	// seperate each of the fields in the line of data
                	list($id, $numSold, $price, $numAvail, $cost, $desc, $imgLoc) = explode(":", $line);
                	
                    //print "part ID = $id *** number sold = $numSold *** Price = $price *** Number Available = $numAvail *** Cost = $cost *** Description 	= $desc *** Image = $imgLoc<br />";
                    
                    // determine total revenue generated
                    $revenue = $numSold * $price;
                    
                    // determine cost of Ineventory
                    $inventoryCost = $numAvail * $cost;
                    
                    // Format currency vlaues
                    $revenue = sprintf("$%.2f", $revenue);
                    $inventoryCost = sprintf("$%.2f", $inventoryCost);
                    
                    // generate table row for this product
                    // lets use a Here Document
                    print <<<TABLEROW

  <tr>
     <td class="diff">
        <blockquote>Item desctiption:<br />
        <strong>$desc</strong>
        <br /><br />

        Part Number = <strong>$id</strong>
        </blockquote>
     </td>
     
     <td class="img">
     <img src="$imgLoc" />
     </td>
     
     <td class="diff">
     	<blockquote>Price: <strong>$price</strong><br />
        Number Sold: <strong>$numSold</strong><br />
        Total Revenue Generated: <strong>$revenue</strong><br /><br />
        Cost: <strong>$$cost</strong><br />
        Left in Inventory: <strong>$numAvail</strong><br />
        Cost of Inventory: <strong>$inventoryCost</strong>
        </blockquote>
     </td>
  </tr>
TABLEROW;

				// Keep track of number of products in this category
                $productCount[$filename]++;
                } // end if valid line of data from fgets()
                
            } // end while
            
            print "</table>\n\n";
            
        } // end foreach
        
        // Display number of products in each selected category
        print "<ul>\n";
        print "<span style=\"font-size:1.2em; font-weight:800;\">";
        print "Product Count by Category</span>\n";
        foreach ($productCount as $filename => $numProducts) {
        
        	print "<li>$reportName[$filename]: $numProducts</li>\n";
        
        } // end foreach selected file
        print "</ul>\n\n";
        
    }	// end else
}	// end else
print <<<BOTTOM

</body>
</html>
BOTTOM;

?>