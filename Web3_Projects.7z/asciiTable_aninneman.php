<?php
print <<<TOP
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ASCII Table Generator</title>

<style>
	table {
		border:solid;
		border-style:groove;
		border-width:medium;
		padding:2px;
	}
	
	.asciiNum {
		
		background-color:beige;
		border:groove;
		border-width:medium;
		azimuth:center;
	}
	
	.conversion {
		background-color:lightgreen;
		border:groove;
		border-width:medium;
		azimuth:center;
	}
	
</style>
</head>

<body>
TOP;
$myForm = <<<MYFORM
<div class="myForm">
<h2>ASCII Table Generator</h2>
	
<form name="rowSelection" action="$_SERVER[PHP_SELF]" method="post">
<label>Number of rows:</label>
<input type="text" name="rowCount" size="10" />
<br /><br />
<input type="submit" name="go" value="Generate ASCII Table" />
</form>
</div>
MYFORM;

if (!isset($_POST[go])) { 	// display the form
	print $myForm;
} // end if
else {

    $current = 0;
	$rowCount = $_POST[rowCount];
    $columnCount = number_format(255 / $rowCount);

    
    print "<table>\n\n";
    print "<tr>\n\n";
    for ($col = 1; $col <= ($columnCount); $col++){
    	print "<th>ASCII</th>";
        print "<th>CHR</th>";
    }
    print "</tr>";
    for ($rows = 0; $rows <= ($rowCount); $rows++){
        print "  <tr>\n";
		$current = $rows;
        // inner for loop to produce columns for this row
        for ($cols = 0; $cols < ($columnCount); $cols++) {
        	$converted = chr($current);
            
            print <<<ENTRY
				<td class="asciiNum">$current</td>
                <td class="conversion">$converted</td>
ENTRY;
            $current = $rowCount + $current;
        }

        print "  </tr>\n";
    }
    print "</table>\n\n";
}


	
print <<<BOTTOM
</body>
</html>
BOTTOM;
?>